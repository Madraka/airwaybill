
<?php $__env->startSection('title'); ?>
Update Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
     <div class="container-fluid">
          <div class="row mb-2">
               <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Update Profile</h1>
               </div><!-- /.col -->
               <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                         <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                         <li class="breadcrumb-item"><a href="#">Users</a></li>
                         <li class="breadcrumb-item active">Update Profile</li>
                    </ol>
               </div><!-- /.col -->
          </div><!-- /.row -->
     </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<!-- Main content -->
<section class="content">
     <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row">
               <div class="col-12">
                    <div class="card card-primary">
                         <div class="card-header">
                              <h3 class="card-title">Update Profile</h3>
                         </div>
                         <?php echo $__env->make('admin.layouts.formerror', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                         <form role="form" action="<?php echo e(route('user.profile.update')); ?>" method="post"
                              enctype="multipart/form-data">
                              <?php echo csrf_field(); ?>
                    
                              <div class="form-group">
                                   <label for="name">Name*:</label>
                                   <input type="text" id="name" name="name" class="form-control" value="<?php echo e($user->name); ?>" required>
                              </div>
                              <div class="form-group">
                                   <label for="email">Email:</label>
                                   <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
                              </div>
                              <div class="form-group">
                                   <label for="oldpassword">Old Password:</label>
                                   <input type="password" name="oldpassword" class="form-control" required>
                              </div>
                              <div class="form-group">
                                   <label for="password">Password:</label>
                                   <input type="password" name="password" class="form-control">
                              </div>
                              <div class="form-group">
                                   <label for="confirmpassword">ConfirmPassword:</label>
                                   <input type="password" name="confirmpassword" class="form-control">
                              </div>
                              <div class="form-group">
                                   <label for="avatar">Avatar:</label>
                                   <input type="file" name="avatar" class="form-control">
                                   <img src="<?php echo e(asset('assets/images/users/' . $user->profile->avatar)); ?>" alt="<?php echo e($user->name); ?>" style="width: 150px; height:auto;">

                              </div>
   
                              <div class="form-group">
                                   <label for="facebook">Facebook:</label>
                                   <input type="url" name="facebook" value="<?php echo e($user->profile->facebook); ?>" class="form-control">
                              </div>
                              <div class="form-group">
                                   <label for="youtube">Youtube:</label>
                                   <input type="url" name="youtube" value="<?php echo e($user->profile->youtube); ?>" class="form-control">
                              </div>
                              <div class="form-group">
                                   <label for="about">About:</label>
                                   <textarea name="about" id="summernote" rows="5" class="form-control">
                                   <?php echo $user->profile->about; ?>

                                   </textarea>
                              </div>
                             
                              <button type="submit" class="btn btn-success">Update</button>
                         </form>
                    </div>
               </div>
          </div>
          <!-- /.row -->
     </div>
     <!--/. container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\airwaybill\resources\views/admin/users/profile.blade.php ENDPATH**/ ?>