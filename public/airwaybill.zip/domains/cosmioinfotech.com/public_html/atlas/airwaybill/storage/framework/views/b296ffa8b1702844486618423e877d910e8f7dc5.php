
<?php $__env->startSection('title'); ?>
Edit User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
     <div class="container-fluid">
          <div class="row mb-2">
               <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Edit User</h1>
               </div><!-- /.col -->
               <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                         <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                         <li class="breadcrumb-item"><a href="#">Users</a></li>
                         <li class="breadcrumb-item active">Edit User</li>
                    </ol>
               </div><!-- /.col -->
          </div><!-- /.row -->
     </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<!-- Main content -->
<section class="content">
     <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row">
               <div class="col-12">
                    <div class="card card-primary">
                         <div class="card-header">
                              <h3 class="card-title">Add User</h3>
                         </div>
                         <?php echo $__env->make('admin.layouts.formerror', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                         <form role="form" action="<?php echo e(route('admin.user.update',['id'=> $user->id ])); ?>" method="post" enctype="multipart/form-data">
                              <?php echo csrf_field(); ?>

                              <div class="form-group">
                                   <label for="name">Name*:</label>
                                   <input type="text" id="name" name="name" class="form-control" value="<?php echo e($user->name); ?>">
                              </div>
                              <div class="form-group">
                                   <label for="email">Email*:</label>
                                   <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
                              </div>
                              <div class="form-group">
                                   <label for="role_id">Select User Role:</label>
                                   <select class="form-control" id="role_id" name="role_id" required>
                                        <option >--Select User Role--</option>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($role->id); ?>" <?php echo e($role->id == $user->role_id ? 'selected' : ''); ?>><?php echo e($role->role); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </select>
                              </div>
                              <div class="form-group">
                                   <label for="password">Password*:</label>
                                   <input type="password" name="password" class="form-control" value="{{ $user->pass" required>
                              </div>
               
                              <button type="submit" class="btn btn-success">Add</button>
                         </form>
                    </div>
               </div>
          </div>
          <!-- /.row -->
     </div>
     <!--/. container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\airwaybill\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>