
<?php $__env->startSection('title','Add Country'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Add Customer</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Customers</a></li>
                    <li class="breadcrumb-item active">Add Customer</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">Add Customer</h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                </div>
            </div>

            <!-- /.card-header -->
            <div class="card-body">
                <?php echo $__env->make('admin.layouts.formerror', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form role="form" action="<?php echo e(route('user.store')); ?>" method="post" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>

                     <div class="form-group">
                          <label for="name">Customer Name*:</label>
                          <input type="text" id="name" name="name" class="form-control">
                     </div>
                     <div class="form-group">
                          <label for="email">Customer Email*:</label>
                          <input type="email" name="email" class="form-control" required>
                     </div>
                     <div class="form-group d-none">
                          <input type="text" name="role_id" value="3">
                     </div>
                     <div class="form-group">
                          <label for="password">Password*:</label>
                          <input type="password" name="password" class="form-control" required>
                     </div>
                     <div class="form-group">
                        <label for="password">Customer Address:</label>
                        <input type="text" name="address" class="form-control" required>
                   </div>
                   <div class="form-group">
                    <label for="phone">Customer Phone:</label>
                    <input type="text" name="phone" class="form-control" required>
               </div>
                   <div class="form-group">
                    <label for="number">Reference Number:</label>
                    <input type="number" name="ref" class="form-control" required>
               </div>
                     <button type="submit" class="btn btn-success">Add Customer</button>
                </form>
            </div>
            <!-- /.card-body -->
        </div>

    </div>
    <!-- /.content -->
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cosmioin/domains/cosmioinfotech.com/public_html/atlas/airwaybill/resources/views/admin/customer/create.blade.php ENDPATH**/ ?>