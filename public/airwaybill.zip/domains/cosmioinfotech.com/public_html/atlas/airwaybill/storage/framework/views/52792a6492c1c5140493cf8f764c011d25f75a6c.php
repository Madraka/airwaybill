
<?php $__env->startSection('title'); ?>
Users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
     <div class="container-fluid">
          <div class="row mb-2">
               <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Users</h1>
               </div><!-- /.col -->
               <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                         <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                         <li class="breadcrumb-item active">Users</li>
                    </ol>
               </div><!-- /.col -->
          </div><!-- /.row -->
     </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<!-- Main content -->
<section class="content">
     <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row">
               <div class="col-12">
                    <div class="card card-primary">
                         <div class="card-header">
                              <h3 class="card-title">Users</h3>
                              <a class="float-right btn btn-success" href="<?php echo e(route('user.create')); ?>">Create</a>
                         </div>
                         <div class="card-body">
                              <table class="table table-hover" id="datatable">
                                   <thead>
                                        <tr>
                                             <th>Image</th>
                                             <th>Name</th>
                                             <th>Role</th>
                                             <th>Action</th>

                                        </tr>
                                   </thead>
                                   <tbody>
                                        <?php if($users->count()>0): ?>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                             <td>
                                                  <img src="" alt="<?php echo e($user->id); ?>" width="50px" height="50px" style="border-radius: 50%;">
                                             </td>
                                             <td>
                                                  <?php echo e($user->name); ?>

                                             </td>
                                             <td>
                                                  <?php if( $user->role_id == 1): ?>
                                                  <p>Admin</p>
                                                  <?php endif; ?>
                                                  <?php if( $user->role_id == 2): ?>
                                                  <p>Staff</p>
                                                  <?php endif; ?>
                                                  <?php if( $user->role_id == 3): ?>
                                                  <p>Customer</p>
                                                  <?php endif; ?>
                                             </td>
                                             <td>
                                                  <?php if(Auth::id() !== $user->id): ?>
                                                  <div class="btn-group" role="group" aria-label="Basic example">
                                                       <a type="button" class="btn btn-primary" href="<?php echo e(route('user.edit',['id'=> $user->id])); ?>">Edit</a>
                                                       <a type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete-modal-<?php echo e($user->id); ?>"><i class="fas fa-trash"></i> Delete</a>
                                                  
                                                  </div>
                                                 
                                                  <!-- The Delete Modal -->
                                                  <div class="modal fade" id="delete-modal-<?php echo e($user->id); ?>">
                                                       <div class="modal-dialog modal-dialog-centered">
                                                            <div class="modal-content text-center">
                                                                 <!-- Modal body -->
                                                                 <div class="modal-body ">
                                                                      <h5 class="mb-4">Do you want to delete User permanently?</h5>
                                                                      <a class="btn btn-danger" href="<?php echo e(route('user.destroy',$user->id)); ?>">Yes</a>
                                                                      <button type="button" class="btn btn-info" data-dismiss="modal">No</button>
                                                                 </div>

                                                            </div>
                                                       </div>
                                                  </div>
                                                  <?php endif; ?>

                                             </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                             <td colspan="5" class="text-center">
                                                  <h3> No Users</h3>
                                             </td>
                                        </tr>
                                        <?php endif; ?>


                                   </tbody>
                              </table>
                         </div>

                    </div>
               </div>
          </div>
          <!-- /.row -->
     </div>
     <!--/. container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\airwaybill\resources\views/admin/users/index.blade.php ENDPATH**/ ?>