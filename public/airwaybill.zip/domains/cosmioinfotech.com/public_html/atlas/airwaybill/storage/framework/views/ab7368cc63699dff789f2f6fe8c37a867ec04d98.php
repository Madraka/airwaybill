<header id="header w-100" class="fixed-top">
    <nav class="navbar navbar-expand-sm">
      <div class="container-fluid">
        <a class="navbar-brand p-0" href="<?php echo e(route('index')); ?>">
          <img src="<?php echo e(asset('/assets/images/settings/'. $sitesetting->company_logo)); ?>" height="42px" class="d-inline-block align-top" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span><i class="fas fa-bars navbutton"></i></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto text-uppercase">
            <li class="mx-2 px-2 nav-item active">
              <a class="nav-link" href="<?php echo e(route('index')); ?>">Home</a>
            </li>
            <li class="mx-2 px-2 nav-item">
              <a class="nav-link" href="<?php echo e(route('front.services')); ?>">Services</a>
            </li>
            <li class="mx-2 px-2 nav-item">
              <a class="nav-link" href="#contact">Contact Us</a>
            </li>
            <li class="mx-2 px-2 nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Login
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  
                <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/admin/dashboard')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="dropdown-item">Login</a>
                        <div class="dropdown-divider"></div>
                        <?php if(Route::has('register')): ?>
                            <a class="dropdown-item" href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
<?php /**PATH /home/cosmioin/domains/cosmioinfotech.com/public_html/atlas/airwaybill/resources/views/front/layouts/header.blade.php ENDPATH**/ ?>