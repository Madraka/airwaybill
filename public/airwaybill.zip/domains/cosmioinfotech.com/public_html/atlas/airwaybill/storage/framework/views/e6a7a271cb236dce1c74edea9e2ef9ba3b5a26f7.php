<?php $__env->startSection('content'); ?>
    <section style="margin-top: 68px;">
      <div class="card">
        <div class="card-body text-light bg-dark">
 
            <div class="row align-items-center">
              <div class="col-12 text-center">
              <?php if(!$page->image == null): ?>
                <div class="image">
                  <img class="card-common" src="<?php echo e(asset('assets/images/pages/'.$page->image)); ?>" style="width: 100%;height:auto;">
                </div>
                <?php endif; ?>
              </div>
              <div class="col-12 px-4">
                <div class="card-title text-center text-uppercase mb-4"><?php echo e($page->title); ?>

             
                </div>
                <?php echo $page->description; ?>}
              </div>
            </div>
         
          </div>
      </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cosmioin/domains/cosmioinfotech.com/public_html/atlas/airwaybill/resources/views/front/page.blade.php ENDPATH**/ ?>