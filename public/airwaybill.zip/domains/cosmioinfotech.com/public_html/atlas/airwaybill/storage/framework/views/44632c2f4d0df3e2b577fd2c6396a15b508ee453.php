<footer class="main-footer">
     <strong>Copyright &copy; 2020 <a href="http://cosmioinfotech.com/" target="_blank">Cosmio Infotech</a>.</strong>
     All rights reserved.
     <div class="float-right d-none d-sm-inline-block">
          <b>Version</b> 1.0.1
     </div>
</footer><?php /**PATH /home/cosmioin/domains/cosmioinfotech.com/public_html/atlas/airwaybill/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>