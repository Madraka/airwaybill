<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CMSService extends Model
{
    protected $fillable = ['order','image','title','description'];
}
