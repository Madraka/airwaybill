<p>Name : {{ $data['name'] }}</p>
<p>Email {{ $data['email'] }}</p>
<p>Contact Number : {{ $data['number'] }}</p>
<p>Message {{ $data['message'] }}.</p>
<p>It would be appriciative, if you gone through this feedback.</p>